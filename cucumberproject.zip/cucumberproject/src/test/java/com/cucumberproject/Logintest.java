package com.cucumberproject;
	import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

	@RunWith(Cucumber.class)
	//@CucumberOptions(format= {"pretty","html:target/cucumber-html-report"},tags= {"@LoginTest"})
//	@CucumberOptions(features=".\\src\\main\\java\\Features\\login.feature",
	@CucumberOptions(features=".\\src\\main\\java\\com.features\\Login.feature",

	glue={"com.stepdefinition"},strict = true ,
	plugin = {"pretty" ,"html:target/Cucumber-reports"})
	public class Logintest{
		
}
